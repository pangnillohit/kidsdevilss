* [SafeMath](#safemath)

# SafeMath

### Math operations with safety checks

- **Constructor**: SafeMath()
- This contract does **not** have a fallback function.
